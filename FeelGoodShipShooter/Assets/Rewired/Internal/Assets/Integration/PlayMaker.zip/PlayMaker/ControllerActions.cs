﻿using UnityEngine;
using System.Collections.Generic;

namespace Rewired.Integration.PlayMaker {

    using HutongGames.PlayMaker;
    using HutongGames.PlayMaker.Actions;
    using HutongGames.Extensions;
    using HutongGames.Utility;
    using System;

    [ActionCategory("Rewired")]
    [Tooltip("Gets the Rewired unique id of this controller. This is not an index. The id is unique among controllers of a specific controller type.")]
    public class RewiredControllerGetId : RewiredControllerGetIntFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue(Controller.id);
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Gets the name of the Controller. For Joysticks, this is drawn from the controller definition for recognized Joysticks. For unrecognized Joysticks, the name returned by the hardware is used instead.")]
    public class RewiredControllerGetName : RewiredControllerGetStringFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue(Controller.name);
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Gets the tag assigned to the controller. Can be used for find a controller by tag.")]
    public class RewiredControllerGetTag : RewiredControllerGetStringFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue(Controller.tag);
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Sets the tag assigned to the controller. Can be used for find a controller by tag.")]
    public class RewiredControllerSetTag : RewiredControllerFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        [RequiredField]
        [Tooltip("The tag to set.")]
        public FsmString tag;

        public override void Reset() {
            base.Reset();
            tag = string.Empty;
        }

        protected override void DoUpdate() {
            Controller.tag = tag.Value;
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Gets the name the controller hardware returns.")]
    public class RewiredControllerGetHardwareName : RewiredControllerGetStringFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue(Controller.hardwareName);
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Gets the type of this controller.")]
    public class RewiredControllerGetType : RewiredControllerFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        [RequiredField, UIHint(UIHint.Variable), ObjectType(typeof(ControllerType))]
        [Tooltip("Store the result in an enum variable.")]
        public FsmEnum storeValue;

        public override void Reset() {
            base.Reset();
            storeValue = null;
        }

        protected override void DoUpdate() {
            UpdateStoreValue(Controller.type);
        }

        protected void UpdateStoreValue(ControllerType newValue) {
            if(!newValue.Equals(storeValue.Value)) { // value changed
                // Store new value
                storeValue.Value = newValue;
            }
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Is the controller connected?")]
    public class RewiredControllerGetIsConnected : RewiredControllerGetBoolFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue(Controller.isConnected);
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Gets the button count in the controller.")]
    public class RewiredControllerGetButtonCount : RewiredControllerGetIntFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue(Controller.buttonCount);
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Gets the string of information from the controller used for identifying unknown controller maps for saving/loading.")]
    public class RewiredControllerGetHardwareIdentifier : RewiredControllerGetStringFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue(Controller.hardwareIdentifier);
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Gets the string representation of the controller map type. Can be used for saving/loading.")]
    public class RewiredControllerGetMapTypeString : RewiredControllerGetStringFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue(Controller.mapTypeString);
        }
    }

    // ControllerWithAxes

    [ActionCategory("Rewired")]
    [Tooltip("Gets the axis count in the controller.")]
    public class RewiredControllerGetAxisCount : RewiredControllerGetIntFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue((Controller as ControllerWithAxes).axis2DCount);
        }

        protected override bool ValidateVars() {
            if(!base.ValidateVars()) return false;
            if(Controller as ControllerWithAxes == null) {
                LogError("Controller is an incompatible type.");
                return false;
            }
            return true;
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Gets the Axis2D count in the controller.")]
    public class RewiredControllerGetAxis2DCount : RewiredControllerGetIntFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue((Controller as ControllerWithAxes).axis2DCount);
        }

        protected override bool ValidateVars() {
            if(!base.ValidateVars()) return false;
            if(Controller as ControllerWithAxes == null) {
                LogError("Controller is an incompatible type.");
                return false;
            }
            return true;
        }
    }

    // Joystick

    // systemId is not supported because ?long is not a supported type in PlayMaker

    [ActionCategory("Rewired")]
    [Tooltip("Gets the unity joystick id of this joystick. This value is only used on platforms that use Unity input as the underlying input source. This value is a 1-based index corresponding to the joystick number in the Unity input manager. Generally, you should never need to use this, but it is exposed for advanced uses. Returns 0 if the platform does not use Unity input or if the joystick is not associated with a Unity joystick.")]
    public class RewiredJoystickGetUnityId : RewiredJoystickGetIntFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue(Joystick.unityId);
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Gets the Rewired GUID associated with this device. A GUID of all zeros is an Unknown Controller.")]
    public class RewiredJoystickGetHardwareTypeGuidString : RewiredJoystickGetStringFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue(Joystick.hardwareTypeGuid.ToString());
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Does this controller support vibration?")]
    public class RewiredJoystickGetSupportsVibration : RewiredJoystickGetBoolFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue(Joystick.supportsVibration);
        }
    }

    [ActionCategory("Rewired")]
    [Tooltip("Gets the number of vibration motors this device supports.")]
    public class RewiredJoystickGetVibrationMotorCount : RewiredJoystickGetIntFsmStateAction {

        protected override bool defaultValue_everyFrame { get { return false; } }

        protected override void DoUpdate() {
            UpdateStoreValue(Joystick.vibrationMotorCount);
        }
    }
}